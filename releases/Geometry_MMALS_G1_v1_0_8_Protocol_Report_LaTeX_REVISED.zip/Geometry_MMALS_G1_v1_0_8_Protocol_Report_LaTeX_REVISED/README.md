# Geometry-MMALS G1 v1.0.8 Revised Protocol Report

Build revision: `reviewer-loss-design-r2`

Compile with:

```bash
xelatex -interaction=nonstopmode Geometry_MMALS_G1_v1_0_8_Direct_Context_Global_Alignment_Protocol_Report.tex
xelatex -interaction=nonstopmode Geometry_MMALS_G1_v1_0_8_Direct_Context_Global_Alignment_Protocol_Report.tex
```

The report documents the normalized functional context, half-chord factor geometry, far-pair separation, path-spread anti-collapse, interval-wise fiber alignment, factor-centroid grounding, ablation design, collapse diagnostics, causal protocol, and claim boundary.
